# Nusa Stationery — Panduan

## Fitur
- Empat akun demo: admin, owner, staff, pelanggan.
- Dashboard ringkasan, grafik batang produk terlaris, daftar stok rendah, transaksi terbaru.
- CRUD produk (tambah, pencarian, filter, hapus dengan perlindungan riwayat transaksi).
- CRUD kategori dan pemasok.
- Transaksi stok masuk dan penjualan dengan perubahan stok otomatis.
- Validasi input, pagination, laporan filter tanggal/jenis, portal pelanggan, dan struk cetak/simpan PDF.
- Database SQLite; tidak perlu menyalakan MySQL/XAMPP.

## Cara menjalankan di Windows
1. Ekstrak ZIP dan buka folder `Nurhazira_Stationery_Updated` di VS Code, yaitu folder yang berisi `artisan` dan `composer.json`.
2. Terminal > New Terminal.
3. `composer install`
4. `copy .env.example .env`
5. `php artisan key:generate`
6. Pastikan `database/database.sqlite` tersedia.
7. `php artisan migrate --seed`
8. `php artisan serve`
9. Buka http://127.0.0.1:8000

Akun demo:
- Admin: `admin@nurhazira-stationery.test`
- Staff: `staff@nurhazira-stationery.test`
- Password keduanya: `password123`

Catatan: admin dan staff saat ini login ke area aplikasi yang sama; pembatasan akses berdasarkan role belum diterapkan. Uji semua fitur di komputer tujuan sebelum dikumpulkan, pahami kode yang digunakan, dan ikuti aturan atribusi/sumber dari dosen.


Pelanggan demo: `customer@nurhazira-stationery.test` (password semua akun: `password123`). Role: admin/owner mengelola data dan laporan, staff mencatat transaksi, pelanggan membuat pesanan demo dan melihat struk. Pembayaran online asli tidak diintegrasikan.



## Role aplikasi
- Admin: mengelola master produk, kategori, pemasok, akun demo, laporan, dan dashboard.
- Staff: operasional stok masuk/keluar dan transaksi, serta cetak struk.
- Pelanggan: katalog, pesanan demo, riwayat pesanan, dan cetak struk pesanan.

Password semua akun demo: `password123`. Pembayaran online sungguhan belum terintegrasi.
