<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\InventoryController;
Route::get('/',fn()=>redirect()->route('login'));
Route::get('/login',[AuthController::class,'form'])->name('login');
Route::post('/login',[AuthController::class,'login'])->name('login.post');
Route::middleware('auth')->group(function(){
 Route::post('/logout',[AuthController::class,'logout'])->name('logout');
 Route::get('/dashboard',[InventoryController::class,'dashboard'])->middleware('role:admin,staff')->name('dashboard');
 Route::get('/products',[InventoryController::class,'products'])->middleware('role:admin,staff')->name('products');
 Route::post('/products',[InventoryController::class,'storeProduct'])->middleware('role:admin')->name('products.store');
 Route::delete('/products/{product}',[InventoryController::class,'deleteProduct'])->middleware('role:admin')->name('products.delete');
 Route::get('/categories',[InventoryController::class,'categories'])->middleware('role:admin,staff')->name('categories');
 Route::post('/categories',[InventoryController::class,'storeCategory'])->middleware('role:admin')->name('categories.store');
 Route::delete('/categories/{category}',[InventoryController::class,'deleteCategory'])->middleware('role:admin')->name('categories.delete');
 Route::get('/suppliers',[InventoryController::class,'suppliers'])->middleware('role:admin,staff')->name('suppliers');
 Route::post('/suppliers',[InventoryController::class,'storeSupplier'])->middleware('role:admin')->name('suppliers.store');
 Route::delete('/suppliers/{supplier}',[InventoryController::class,'deleteSupplier'])->middleware('role:admin')->name('suppliers.delete');
 Route::get('/transactions',[InventoryController::class,'transactions'])->middleware('role:admin,staff')->name('transactions');
 Route::post('/purchases',[InventoryController::class,'purchase'])->middleware('role:admin,staff')->name('purchases.store');
 Route::post('/sales',[InventoryController::class,'sale'])->middleware('role:admin,staff')->name('sales.store');
 Route::get('/reports',[InventoryController::class,'report'])->middleware('role:admin')->name('reports');
 Route::get('/receipts/transaction/{transaction}',[InventoryController::class,'receipt'])->middleware('role:admin,staff')->name('receipts.show');
 Route::get('/customer',[InventoryController::class,'customerPortal'])->middleware('role:customer')->name('customer.portal');
 Route::post('/customer/orders',[InventoryController::class,'customerOrder'])->middleware('role:customer')->name('customer.orders.store');
 Route::get('/receipts/order/{order}',[InventoryController::class,'customerReceipt'])->middleware('role:customer')->name('receipts.customer');
});
