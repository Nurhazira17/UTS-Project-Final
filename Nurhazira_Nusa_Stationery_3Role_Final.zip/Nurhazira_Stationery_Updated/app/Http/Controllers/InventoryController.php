<?php
namespace App\Http\Controllers;
use App\Models\{Product,Category,Supplier,InventoryTransaction};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
class InventoryController extends Controller {
 public function dashboard(){
  $top=InventoryTransaction::select('product_id',DB::raw('SUM(quantity) as sold'))->where('type','sale')->groupBy('product_id')->orderByDesc('sold')->with('product')->limit(5)->get();
  return view('dashboard',['productCount'=>Product::count(),'lowCount'=>Product::whereColumn('stock','<=','minimum_stock')->count(),'categoryCount'=>Category::count(),'supplierCount'=>Supplier::count(),'salesTotal'=>InventoryTransaction::where('type','sale')->sum('total'),'monthSales'=>InventoryTransaction::where('type','sale')->whereMonth('created_at',now()->month)->sum('total'),'top'=>$top,'low'=>Product::with('category')->whereColumn('stock','<=','minimum_stock')->orderBy('stock')->limit(6)->get(),'recent'=>InventoryTransaction::with('product')->latest()->limit(8)->get()]);
 }
 public function products(Request $r){$products=Product::with('category')->when($r->q,function($q,$term){$q->where(fn($s)=>$s->where('name','like',"%$term%")->orWhere('sku','like',"%$term%"));})->when($r->category_id,fn($q,$id)=>$q->where('category_id',$id))->when($r->status==='low',fn($q)=>$q->whereColumn('stock','<=','minimum_stock'))->latest()->paginate(10)->withQueryString();return view('products',['products'=>$products,'categories'=>Category::orderBy('name')->get()]);}
 public function storeProduct(Request $r){$d=$r->validate(['category_id'=>'required|exists:categories,id','sku'=>'required|string|max:40|unique:products,sku','name'=>'required|string|max:120','description'=>'nullable|string|max:500','purchase_price'=>'required|numeric|min:0','selling_price'=>'required|numeric|min:0','stock'=>'required|integer|min:0','minimum_stock'=>'required|integer|min:0']);Product::create($d);return back()->with('ok','Produk ditambahkan.');}
 public function deleteProduct(Product $product){if($product->transactions()->exists())return back()->withErrors(['product'=>'Produk memiliki riwayat transaksi sehingga tidak dapat dihapus.']);$product->delete();return back()->with('ok','Produk dihapus.');}
 public function categories(){return view('categories',['categories'=>Category::withCount('products')->orderBy('name')->get()]);}
 public function storeCategory(Request $r){$d=$r->validate(['name'=>'required|string|max:80|unique:categories,name','description'=>'nullable|string|max:250']);Category::create($d);return back()->with('ok','Kategori ditambahkan.');}
 public function deleteCategory(Category $category){if($category->products()->exists())return back()->withErrors(['category'=>'Kategori masih dipakai produk.']);$category->delete();return back()->with('ok','Kategori dihapus.');}
 public function suppliers(){return view('suppliers',['suppliers'=>Supplier::withCount('transactions')->orderBy('name')->get()]);}
 public function storeSupplier(Request $r){$d=$r->validate(['name'=>'required|string|max:120','phone'=>'nullable|string|max:30','email'=>'nullable|email|max:120','address'=>'nullable|string|max:250']);Supplier::create($d);return back()->with('ok','Pemasok ditambahkan.');}
 public function deleteSupplier(Supplier $supplier){$supplier->delete();return back()->with('ok','Pemasok dihapus.');}
 public function transactions(){return view('transactions',['transactions'=>InventoryTransaction::with(['product','supplier','user'])->latest()->paginate(12),'products'=>Product::orderBy('name')->get(),'suppliers'=>Supplier::orderBy('name')->get()]);}
 public function purchase(Request $r){$d=$r->validate(['product_id'=>'required|exists:products,id','supplier_id'=>'required|exists:suppliers,id','quantity'=>'required|integer|min:1','unit_price'=>'required|numeric|min:0','notes'=>'nullable|string|max:250']);DB::transaction(function()use($d){$p=Product::lockForUpdate()->findOrFail($d['product_id']);$p->increment('stock',$d['quantity']);InventoryTransaction::create(['type'=>'purchase','reference'=>'IN-'.now()->format('ymdHis').random_int(10,99),'product_id'=>$p->id,'supplier_id'=>$d['supplier_id'],'user_id'=>auth()->id(),'quantity'=>$d['quantity'],'unit_price'=>$d['unit_price'],'total'=>$d['quantity']*$d['unit_price'],'notes'=>$d['notes']??null]);});return back()->with('ok','Stok masuk tercatat.');}
 public function sale(Request $r){$d=$r->validate(['product_id'=>'required|exists:products,id','quantity'=>'required|integer|min:1','notes'=>'nullable|string|max:250']);DB::transaction(function()use($d){$p=Product::lockForUpdate()->findOrFail($d['product_id']);if($p->stock<$d['quantity'])throw ValidationException::withMessages(['quantity'=>'Stok tidak cukup.']);$p->decrement('stock',$d['quantity']);InventoryTransaction::create(['type'=>'sale','reference'=>'OUT-'.now()->format('ymdHis').random_int(10,99),'product_id'=>$p->id,'user_id'=>auth()->id(),'quantity'=>$d['quantity'],'unit_price'=>$p->selling_price,'total'=>$d['quantity']*$p->selling_price,'notes'=>$d['notes']??null]);});return back()->with('ok','Penjualan tercatat; stok berkurang.');}
 public function report(Request $r){$rows=InventoryTransaction::with(['product','user'])->when($r->type,fn($q,$type)=>$q->where('type',$type))->when($r->from,fn($q,$date)=>$q->whereDate('created_at','>=',$date))->when($r->to,fn($q,$date)=>$q->whereDate('created_at','<=',$date))->latest()->get();return view('reports',['rows'=>$rows,'from'=>$r->from,'to'=>$r->to,'type'=>$r->type,'sales'=>$rows->where('type','sale')->sum('total')]);}

 public function receipt(\App\Models\InventoryTransaction $transaction) {
  $transaction->load(['product','supplier','user']); return view('receipt',['t'=>$transaction]);
 }
 public function customerReceipt(\App\Models\CustomerOrder $order) {
  abort_unless($order->user_id===auth()->id(),403);$order->load(['product','user']);return view('customer_receipt',['order'=>$order]);
 }
 public function customerPortal() {
  return view('customer',['products'=>Product::with('category')->where('stock','>',0)->orderBy('name')->get(),
   'orders'=>\App\Models\CustomerOrder::with('product')->where('user_id',auth()->id())->latest()->limit(20)->get()]);
 }
 public function customerOrder(Request $r) {
  $d=$r->validate(['product_id'=>'required|exists:products,id','quantity'=>'required|integer|min:1']);
  $order=\Illuminate\Support\Facades\DB::transaction(function()use($d){
   $p=Product::lockForUpdate()->findOrFail($d['product_id']);
   if($p->stock<$d['quantity'])throw \Illuminate\Validation\ValidationException::withMessages(['quantity'=>'Stok tidak cukup.']);
   $p->decrement('stock',$d['quantity']);$total=$d['quantity']*$p->selling_price;
   return \App\Models\CustomerOrder::create(['receipt_number'=>'RC-'.now()->format('ymdHis').random_int(100,999),'product_id'=>$p->id,'user_id'=>auth()->id(),'quantity'=>$d['quantity'],'unit_price'=>$p->selling_price,'total'=>$total,'status'=>'paid']);
  });
  return redirect()->route('customer.portal')->with('ok','Pesanan dibuat. Struk tersedia pada riwayat pesanan.');
 }

}
