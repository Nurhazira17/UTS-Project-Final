<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class AuthController extends Controller {
 public function form(){return view('login');}
 public function login(Request $r){
  $d=$r->validate(['email'=>'required|email','password'=>'required']);
  if(!Auth::attempt($d)) return back()->withErrors(['email'=>'Email atau password salah.'])->onlyInput('email');
  $r->session()->regenerate();
  return redirect()->intended(Auth::user()->role==='customer'?route('customer.portal'):route('dashboard'));
 }
 public function logout(Request $r){Auth::logout();$r->session()->invalidate();$r->session()->regenerateToken();return redirect()->route('login');}
}
