<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class CustomerOrder extends Model {
 protected $fillable=['receipt_number','product_id','user_id','quantity','unit_price','total','status'];
 public function product(){return $this->belongsTo(Product::class);}
 public function user(){return $this->belongsTo(User::class);}
}
