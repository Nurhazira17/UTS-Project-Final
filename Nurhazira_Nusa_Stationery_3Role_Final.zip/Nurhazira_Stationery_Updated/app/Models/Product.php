<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Product extends Model {
 protected $fillable=['category_id','sku','name','description','purchase_price','selling_price','stock','minimum_stock'];
 public function category(){return $this->belongsTo(Category::class);}
 public function transactions(){return $this->hasMany(InventoryTransaction::class);}
 public function getStockStatusAttribute():string{return $this->stock<=$this->minimum_stock?'Rendah':'Aman';}
}
