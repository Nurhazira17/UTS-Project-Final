<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class InventoryTransaction extends Model {
 protected $fillable=['type','reference','product_id','supplier_id','user_id','quantity','unit_price','total','notes'];
 public function product(){return $this->belongsTo(Product::class);}
 public function supplier(){return $this->belongsTo(Supplier::class);}
 public function user(){return $this->belongsTo(User::class);}
}
