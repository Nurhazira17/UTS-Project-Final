<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void{
 Schema::create('categories',function(Blueprint $t){$t->id();$t->string('name')->unique();$t->string('description')->nullable();$t->timestamps();});
 Schema::create('suppliers',function(Blueprint $t){$t->id();$t->string('name');$t->string('phone')->nullable();$t->string('email')->nullable();$t->string('address')->nullable();$t->timestamps();});
 Schema::create('products',function(Blueprint $t){$t->id();$t->foreignId('category_id')->constrained()->restrictOnDelete();$t->string('sku')->unique();$t->string('name');$t->text('description')->nullable();$t->decimal('purchase_price',12,2);$t->decimal('selling_price',12,2);$t->unsignedInteger('stock')->default(0);$t->unsignedInteger('minimum_stock')->default(5);$t->timestamps();});
 Schema::create('inventory_transactions',function(Blueprint $t){$t->id();$t->string('type');$t->string('reference')->unique();$t->foreignId('product_id')->constrained()->restrictOnDelete();$t->foreignId('supplier_id')->nullable()->constrained()->nullOnDelete();$t->foreignId('user_id')->constrained()->restrictOnDelete();$t->unsignedInteger('quantity');$t->decimal('unit_price',12,2);$t->decimal('total',14,2);$t->string('notes')->nullable();$t->timestamps();});
 }
 public function down():void{Schema::dropIfExists('inventory_transactions');Schema::dropIfExists('products');Schema::dropIfExists('suppliers');Schema::dropIfExists('categories');}
};
