<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {Schema::create('customer_orders',function(Blueprint $t){
  $t->id();$t->string('receipt_number')->unique();$t->foreignId('product_id')->constrained()->restrictOnDelete();
  $t->foreignId('user_id')->constrained()->restrictOnDelete();$t->unsignedInteger('quantity');
  $t->decimal('unit_price',12,2);$t->decimal('total',14,2);$t->string('status')->default('paid');$t->timestamps();
 });}
 public function down():void {Schema::dropIfExists('customer_orders');}
};
