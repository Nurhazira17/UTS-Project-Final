<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
class DatabaseSeeder extends Seeder {
 public function run(): void {
 User::firstOrCreate(['email'=>'admin@nurhazira-stationery.test'],['name'=>'Admin Demo','password'=>Hash::make('password123'),'role'=>'admin']);
 User::firstOrCreate(['email'=>'staff@nurhazira-stationery.test'],['name'=>'Staff Demo','password'=>Hash::make('password123'),'role'=>'staff']);
 User::firstOrCreate(['email'=>'customer@nurhazira-stationery.test'],['name'=>'Pelanggan Demo','password'=>Hash::make('password123'),'role'=>'customer']);
 }
}
